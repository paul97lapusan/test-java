package com.inditex.inditexapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InditexApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(InditexApiApplication.class, args);
	}

}
