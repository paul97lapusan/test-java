package com.inditex.inditexapi.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.inditex.inditexapi.model.Prices;

@Repository
public interface PricesRepository extends JpaRepository<Prices, Long> {

	@Query("select p from Prices p where p.startDate <= :currentDate AND p.endDate > :currentDate "
			+ "AND p.productId = :productId AND p.brandId = :brandId")
	List<Prices> findAllWithCurrentDateBetween(@Param("currentDate") Date currentDate, @Param("productId") Long productId, 
			@Param("brandId") Long brandId);

}
