package com.inditex.inditexapi.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.inditex.inditexapi.model.Prices;
import com.inditex.inditexapi.repository.PricesRepository;

@RestController

public class PricesController {
	
	@Autowired
	private PricesRepository pricesRepository;
	
	@GetMapping("/prices")
	public ResponseEntity<List<Prices>> getPricesByFilter(@RequestParam Date currentDate, @RequestParam Long productId, 
			@RequestParam Long brandId) {
		return new ResponseEntity<List<Prices>>(pricesRepository.findAllWithCurrentDateBetween(currentDate, productId, brandId), 
				HttpStatus.OK);
	}
	
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public void handleMissingParams(MissingServletRequestParameterException ex) {
	    String name = ex.getParameterName();
	    System.out.println(name + " parameter is missing");
	}
	
}
