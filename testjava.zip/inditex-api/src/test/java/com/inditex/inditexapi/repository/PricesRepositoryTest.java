package com.inditex.inditexapi.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.inditex.inditexapi.model.Prices;

class PricesRepositoryTest {

	@Autowired
    private PricesRepository repository;
	
	@Test
	void testFindAllWithCurrentDateBetween() {
		fail("Not yet implemented");
	}
	
	@Test
    public void case1_thenPrice1Returned() throws ParseException {
        List<Prices> result = repository.findAllWithCurrentDateBetween(
          new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").parse("2020-06-14 10.00.00"), 35455L, 1L);

        assertEquals(1, result.size());
    }

    @Test
    public void case2_thenPrice1And2Returned() throws ParseException {
        List<Prices> result = repository.findAllWithCurrentDateBetween(
          new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").parse("2020-06-14 16.00.00"), 35455L, 1L);

        assertEquals(2, result.size());
    }

    @Test
    public void case3_thenPrice1Returned() throws ParseException {
        List<Prices> result = repository.findAllWithCurrentDateBetween(
          new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").parse("2020-06-14 21.00.00"), 35455L, 1L);

        assertEquals(1, result.size());
    }
    
    @Test
    public void case4_thenPrice1And3Returned() throws ParseException {
        List<Prices> result = repository.findAllWithCurrentDateBetween(
          new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").parse("2020-06-15 10.00.00"), 35455L, 1L);

        assertEquals(2, result.size());
    }
    
    @Test
    public void case5_thenPrice1And4Returned() throws ParseException {
        List<Prices> result = repository.findAllWithCurrentDateBetween(
          new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").parse("2020-06-16 21.00.00"), 35455L, 1L);

        assertEquals(2, result.size());
    }

}



